import logging

def configure_logging() -> None:
    pass